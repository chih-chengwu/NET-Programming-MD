﻿namespace ASMD
{
    partial class AddSubMulDiv
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.txtAdd1 = new System.Windows.Forms.TextBox();
            this.txtAdd2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAnswerA = new System.Windows.Forms.TextBox();
            this.butRandomAdd = new System.Windows.Forms.Button();
            this.butScoreA = new System.Windows.Forms.Button();
            this.txtScoreA = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.butRandomSub = new System.Windows.Forms.Button();
            this.butScoreSub = new System.Windows.Forms.Button();
            this.txtSub1 = new System.Windows.Forms.TextBox();
            this.txtSub2 = new System.Windows.Forms.TextBox();
            this.txtAnswerB = new System.Windows.Forms.TextBox();
            this.txtScoreB = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtAdd1
            // 
            this.txtAdd1.Font = new System.Drawing.Font("標楷體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtAdd1.Location = new System.Drawing.Point(227, 130);
            this.txtAdd1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAdd1.Name = "txtAdd1";
            this.txtAdd1.Size = new System.Drawing.Size(100, 35);
            this.txtAdd1.TabIndex = 0;
            // 
            // txtAdd2
            // 
            this.txtAdd2.Font = new System.Drawing.Font("標楷體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtAdd2.Location = new System.Drawing.Point(385, 132);
            this.txtAdd2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAdd2.Name = "txtAdd2";
            this.txtAdd2.Size = new System.Drawing.Size(100, 35);
            this.txtAdd2.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(344, 138);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(21, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "+";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(533, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 23);
            this.label2.TabIndex = 3;
            this.label2.Text = "=";
            // 
            // txtAnswerA
            // 
            this.txtAnswerA.Font = new System.Drawing.Font("標楷體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtAnswerA.Location = new System.Drawing.Point(617, 138);
            this.txtAnswerA.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAnswerA.Name = "txtAnswerA";
            this.txtAnswerA.Size = new System.Drawing.Size(100, 35);
            this.txtAnswerA.TabIndex = 5;
            // 
            // butRandomAdd
            // 
            this.butRandomAdd.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.butRandomAdd.Location = new System.Drawing.Point(35, 130);
            this.butRandomAdd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.butRandomAdd.Name = "butRandomAdd";
            this.butRandomAdd.Size = new System.Drawing.Size(107, 39);
            this.butRandomAdd.TabIndex = 4;
            this.butRandomAdd.Text = "Refresh";
            this.butRandomAdd.UseVisualStyleBackColor = true;
            this.butRandomAdd.Click += new System.EventHandler(this.butRandomAdd_Click);
            // 
            // butScoreA
            // 
            this.butScoreA.Font = new System.Drawing.Font("標楷體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.butScoreA.Location = new System.Drawing.Point(899, 134);
            this.butScoreA.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.butScoreA.Name = "butScoreA";
            this.butScoreA.Size = new System.Drawing.Size(93, 38);
            this.butScoreA.TabIndex = 6;
            this.butScoreA.Text = "評分";
            this.butScoreA.UseVisualStyleBackColor = true;
            this.butScoreA.Click += new System.EventHandler(this.butScoreA_Click);
            // 
            // txtScoreA
            // 
            this.txtScoreA.Font = new System.Drawing.Font("標楷體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtScoreA.Location = new System.Drawing.Point(775, 138);
            this.txtScoreA.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtScoreA.Name = "txtScoreA";
            this.txtScoreA.Size = new System.Drawing.Size(73, 35);
            this.txtScoreA.TabIndex = 7;
            this.txtScoreA.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("標楷體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(637, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 25);
            this.label3.TabIndex = 8;
            this.label3.Text = "答案";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("標楷體", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(775, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 25);
            this.label4.TabIndex = 9;
            this.label4.Text = "成績";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("標楷體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(47, 15);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(306, 27);
            this.label7.TabIndex = 23;
            this.label7.Text = "Notice...............";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(35, 45);
            this.textBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(353, 25);
            this.textBox3.TabIndex = 24;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(421, 36);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(164, 25);
            this.textBox4.TabIndex = 25;
            // 
            // butRandomSub
            // 
            this.butRandomSub.Location = new System.Drawing.Point(35, 225);
            this.butRandomSub.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.butRandomSub.Name = "butRandomSub";
            this.butRandomSub.Size = new System.Drawing.Size(100, 29);
            this.butRandomSub.TabIndex = 26;
            this.butRandomSub.Text = "Refresh";
            this.butRandomSub.UseVisualStyleBackColor = true;
            this.butRandomSub.Click += new System.EventHandler(this.butRandomSub_Click);
            // 
            // butScoreSub
            // 
            this.butScoreSub.Location = new System.Drawing.Point(899, 224);
            this.butScoreSub.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.butScoreSub.Name = "butScoreSub";
            this.butScoreSub.Size = new System.Drawing.Size(100, 29);
            this.butScoreSub.TabIndex = 27;
            this.butScoreSub.Text = "評分";
            this.butScoreSub.UseVisualStyleBackColor = true;
            this.butScoreSub.Click += new System.EventHandler(this.butScoreSub_Click);
            // 
            // txtSub1
            // 
            this.txtSub1.Location = new System.Drawing.Point(227, 224);
            this.txtSub1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSub1.Name = "txtSub1";
            this.txtSub1.Size = new System.Drawing.Size(108, 25);
            this.txtSub1.TabIndex = 28;
            // 
            // txtSub2
            // 
            this.txtSub2.Location = new System.Drawing.Point(385, 225);
            this.txtSub2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSub2.Name = "txtSub2";
            this.txtSub2.Size = new System.Drawing.Size(100, 25);
            this.txtSub2.TabIndex = 29;
            // 
            // txtAnswerB
            // 
            this.txtAnswerB.Location = new System.Drawing.Point(617, 224);
            this.txtAnswerB.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtAnswerB.Name = "txtAnswerB";
            this.txtAnswerB.Size = new System.Drawing.Size(100, 25);
            this.txtAnswerB.TabIndex = 30;
            // 
            // txtScoreB
            // 
            this.txtScoreB.Location = new System.Drawing.Point(775, 225);
            this.txtScoreB.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtScoreB.Name = "txtScoreB";
            this.txtScoreB.Size = new System.Drawing.Size(73, 25);
            this.txtScoreB.TabIndex = 31;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(353, 231);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(12, 15);
            this.label5.TabIndex = 32;
            this.label5.Text = "-";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(545, 228);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(15, 15);
            this.label6.TabIndex = 33;
            this.label6.Text = "=";
            // 
            // AddSubMulDiv
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1027, 498);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtScoreB);
            this.Controls.Add(this.txtAnswerB);
            this.Controls.Add(this.txtSub2);
            this.Controls.Add(this.txtSub1);
            this.Controls.Add(this.butScoreSub);
            this.Controls.Add(this.butRandomSub);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtScoreA);
            this.Controls.Add(this.butScoreA);
            this.Controls.Add(this.butRandomAdd);
            this.Controls.Add(this.txtAnswerA);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtAdd2);
            this.Controls.Add(this.txtAdd1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "AddSubMulDiv";
            this.Text = "加減乘除";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtAdd1;
        private System.Windows.Forms.TextBox txtAdd2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAnswerA;
        private System.Windows.Forms.Button butRandomAdd;
        private System.Windows.Forms.Button butScoreA;
        private System.Windows.Forms.TextBox txtScoreA;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button butRandomSub;
        private System.Windows.Forms.Button butScoreSub;
        private System.Windows.Forms.TextBox txtSub1;
        private System.Windows.Forms.TextBox txtSub2;
        private System.Windows.Forms.TextBox txtAnswerB;
        private System.Windows.Forms.TextBox txtScoreB;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}

