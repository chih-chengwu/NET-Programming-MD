﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ASMD
{
    public partial class AddSubMulDiv : Form
    {
        public AddSubMulDiv()
        {
            InitializeComponent();
        }

        private void butRandomAdd_Click(object sender, EventArgs e)
        {
            Random rdA = new Random();
            txtAdd1.Text = rdA.Next(0, 100).ToString();
            txtAdd2.Text = Convert.ToString(rdA.Next(0, 100));
        }

        private void butScoreA_Click(object sender, EventArgs e)
        {
            txtScoreA.ForeColor = Color.Black;
            txtScoreA.Text = "";
            
            Int32 mInteger;
            if (txtAdd1.Text.Trim() == "" || !Int32.TryParse(txtAdd1.Text.Trim(), out mInteger))               
            {
                MessageBox.Show("數字 1 不為數字。" + "\r\n\r\n" + "按任一鍵離開!", "敬請確認");
                return;
            }
            else if (txtAdd2.Text.Trim() == "" || !Int32.TryParse(txtAdd2.Text.Trim(), out mInteger))
            {
                MessageBox.Show("數字 2 不為數字。" + "\r\n\r\n" + "按任一鍵離開!", "敬請確認");
                return;
            }
            else if (txtAnswerA.Text.Trim() == "" || !Int32.TryParse(txtAnswerA.Text.Trim(), out mInteger))
            {
                MessageBox.Show("答案 不為數字。" + "\r\n\r\n" + "按任一鍵離開!", "警告");
                return;
            }

            if (Int32.Parse (txtAnswerA.Text.Trim()) == Int32.Parse(txtAdd1.Text.Trim()) + Int32.Parse(txtAdd2.Text.Trim()))
            {
                txtScoreA.ForeColor = Color.Blue;
                txtScoreA.Text = "100";                
            }
            else
            {
                txtScoreA.ForeColor = Color.Red;
                txtScoreA.Text = "0";                
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            MessageBox.Show("數字 2 不為數字。" + txtAdd1.Text.Trim() + "按任一鍵離開!", "敬請確認");

            
            Int32 mInteger;
            mInteger = 0;
            MessageBox.Show(Convert.ToString(mInteger));
            Int32.TryParse(txtAdd1.Text.Trim(), out mInteger);
            MessageBox.Show(Convert.ToString(mInteger));
            //string AAA;
            //AAA = "";
            //Random Rnd = new Random(); //加入Random，產生的數字不會重覆
            //for (int i = 0; i < 20; i++)
            //{
            //    AAA = AAA + "number:" + Convert.ToString(Rnd.Next(0, 5)) + "\r";
            //}
            //MessageBox.Show(AAA);
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            String[] values = { null, "160519", "9432.0", "16,667",
                          "   -322   ", "+4302", "(100);", "01FA" };
            foreach (var value in values)
            {
                int number;

                bool success = Int32.TryParse(value, out number);
                if (success)
                {
                    
                    MessageBox.Show("success Convert: " + value + " to  " + Convert.ToString(number));
                }
                else
                {
                   
                    MessageBox.Show("failed Convert: " + value + " to  " + Convert.ToString(number));
                }
            }
        }

        private void butRandomSub_Click(object sender, EventArgs e)
        {
            Random rdA = new Random();
            txtSub1.Text = rdA.Next(0, 100).ToString();
            txtSub2.Text = Convert.ToString(rdA.Next(0, 100));
        }

        private void butScoreSub_Click(object sender, EventArgs e)
        {
            txtScoreB.ForeColor = Color.Black;
            txtScoreB.Text = "";

            Int32 mInteger;
            if (txtSub1.Text.Trim() == "" || !Int32.TryParse(txtSub1.Text.Trim(), out mInteger))
            {
                MessageBox.Show("數字 1 不為數字。" + "\r\n\r\n" + "按任一鍵離開!", "敬請確認");
                return;
            }
            else if (txtSub2.Text.Trim() == "" || !Int32.TryParse(txtSub2.Text.Trim(), out mInteger))
            {
                MessageBox.Show("數字 2 不為數字。" + "\r\n\r\n" + "按任一鍵離開!", "敬請確認");
                return;
            }
            else if (txtAnswerB.Text.Trim() == "" || !Int32.TryParse(txtAnswerB.Text.Trim(), out mInteger))
            {
                MessageBox.Show("答案 不為數字。" + "\r\n\r\n" + "按任一鍵離開!", "警告");
                return;
            }

            if (Int32.Parse(txtAnswerB.Text.Trim()) == Int32.Parse(txtSub1.Text.Trim()) + Int32.Parse(txtSub2.Text.Trim()))
            {
                txtScoreB.ForeColor = Color.Blue;
                txtScoreB.Text = "100";
            }
            else
            {
                txtScoreB.ForeColor = Color.Red;
                txtScoreB.Text = "0";
            }
        }
    }
}
